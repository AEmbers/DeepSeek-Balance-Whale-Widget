const { app, BrowserWindow, Tray, Menu, nativeImage, screen, ipcMain, globalShortcut, shell, protocol, session, net } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const { UiStateStore } = require('./ui-state-store.cjs');
const { shutdownCompanion } = require('./lifecycle.cjs');
const { externalWebUrl } = require('./external-links.cjs');
const { createVisibilityController } = require('./visibility.cjs');
const { pathToFileURL } = require('node:url');
const root = path.resolve(__dirname, '..');
const dataDir = process.argv.find(a => a.startsWith('--whale-data='))?.slice(13);
const fixture = process.env.WHALE_DESKTOP_TEST === '1';
const initialHost = (() => { try { const h = JSON.parse(process.env.WHALE_INITIAL_HOST || 'null'); return h?.hostAlive ? h : null; } catch { return null; } })();
const startupAt = Date.now();
const startup = { revision: 'complete-audit-v1', requestedAt: Number(process.env.WHALE_LAUNCH_TIME) || startupAt, mainAt: startupAt, phases: {} };
const markStartup = phase => { if (startup.phases[phase] == null) startup.phases[phase] = Date.now() - startup.requestedAt; };
markStartup('main');
// Leave device/driver safety checks to Chromium; do not bypass the GPU blocklist.
app.commandLine.appendSwitch('enable-gpu-rasterization');
if (!dataDir || !path.isAbsolute(dataDir) || (!fixture && !process.argv.includes('--supervised'))) app.exit(1);
protocol.registerSchemesAsPrivileged([{ scheme: 'whale', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }]);
fs.mkdirSync(path.join(dataDir, 'desktop-profile'), { recursive: true });
app.setPath('userData', path.join(dataDir, 'desktop-profile'));
const lock = app.requestSingleInstanceLock();
let window, tray, dispatcher, bridge, lastHost = initialHost, owner = '', appliedBounds = '', rendererReady = false, quitting = false, manuallyHidden = false, hostHeartbeat = Date.now();
const rendererErrors = [];
const fixtureOpenedLinks = [];
let hostSequence = -1;
let appliedNativeSize = '';
const stateFile = path.join(dataDir, 'ui-state.json');
const read = (f, fallback = {}) => { try { return JSON.parse(fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, '')); } catch { return fallback; } };
const save = (file, value) => { const temp = file + '.' + process.pid + '.tmp'; fs.writeFileSync(temp, JSON.stringify(value, null, 2)); fs.renameSync(temp, file); };
const uiStore = new UiStateStore(stateFile);
const values = () => uiStore.get();
const storeValues = input => uiStore.set(input);
let gpuStatus = null, inputEnabled = false, keyboardFocus = false, testCursor = null, lastCursor = '', presents = 0;
let trustedGestureAt = 0;
app.on('gpu-info-update', () => {
  gpuStatus = { hardwareAcceleration: app.isHardwareAccelerationEnabled(), features: app.getGPUFeatureStatus(), electron: process.versions.electron, chromium: process.versions.chrome };
  fs.promises.writeFile(path.join(dataDir, 'render-status.json'), JSON.stringify(gpuStatus, null, 2)).catch(() => {});
});
function invalidate() { if (window && !window.isDestroyed()) { presents++; window.webContents.invalidate(); } }
function setKeyboardFocus(editing) {
  if (!window || window.isDestroyed() || keyboardFocus === editing) return;
  keyboardFocus = editing;
  if (editing) window.focus();
}
function sendCursor(force = false) {
  if (!window || window.isDestroyed() || !rendererReady || !window.isVisible()) return;
  const bounds = window.getContentBounds(), cursor = screen.getCursorScreenPoint();
  const point = fixture && testCursor ? testCursor : { x: cursor.x - bounds.x, y: cursor.y - bounds.y };
  const encoded = point.x + ',' + point.y;
  if (force || encoded !== lastCursor) { lastCursor = encoded; window.webContents.send('whale-cursor', point); }
}
function setTestCursor(point) { if (fixture) { testCursor = point; sendCursor(true); } }
const visibilityController = createVisibilityController({
  getWindow: () => window,
  getState: () => ({ ready: rendererReady, host: lastHost, fixture, manuallyHidden, quitting }),
  onShown: () => {
    if (startup.phases.interactive == null) {
      markStartup('interactive');
      fs.promises.writeFile(path.join(dataDir, 'startup-timings.json'), JSON.stringify(startup, null, 2)).catch(() => {});
    }
  },
});
function visibility() {
  visibilityController.update();
}
function show() { manuallyHidden = false; visibilityController.requestRecovery(); }
function toggle() { if (manuallyHidden) show(); else { manuallyHidden = true; visibility(); } }
function pauseAndQuit() { if (lastHost?.hostPid) save(path.join(dataDir, 'pause-until-host-exit.json'), { hostPid: lastHost.hostPid }); app.quit(); }
function isMainFrame(event) { return event.sender === window?.webContents && event.senderFrame === window.webContents.mainFrame; }
async function openWebLink(value, gestureRequired = true) {
  if (gestureRequired && (!trustedGestureAt || Date.now() - trustedGestureAt > 1000)) return false;
  trustedGestureAt = 0;
  let target = value;
  if (value === 'whale://widget/provider-dashboard') {
    try { target = dispatcher.whale.config.resolve().dashboardUrl; } catch { return false; }
  }
  const url = externalWebUrl(target);
  if (!url) return false;
  try {
    if (fixture) fixtureOpenedLinks.push(url);
    else await shell.openExternal(url);
    return true;
  } catch { return false; }
}
async function setHost(host) {
  if (!host || typeof host.hostAlive !== 'boolean') return;
  if (Number.isSafeInteger(host.serial)) { if (host.serial <= hostSequence) return; hostSequence = host.serial; }
  hostHeartbeat = Date.now(); lastHost = host;
  if (!host.hostAlive) { if (window) app.quit(); return; }
  if (!window) return;
  if (host.attached) markStartup('attached');
  // Native events own position. Only Electron may resize its non-resizable
  // viewport; it updates the corresponding native min/max tracking sizes.
  if (host.nativeFollowing && host.visible && host.bounds && ['width','height','x','y'].every(k => Number.isFinite(host.bounds[k]))) {
    const current = window.getBounds();
    const scale = Number.isFinite(host.dpi) && host.dpi >= 96 ? host.dpi / 96 : screen.getDisplayMatching(current).scaleFactor;
    const width = Math.round(host.bounds.width / scale), height = Math.round(host.bounds.height / scale);
    const sizeKey = [host.window, width, height, scale].join(':');
    // getBounds encloses fractional DIP edges and can differ by one DIP as x
    // changes. Compare requested sizes, not that rounded result, on heartbeats.
    if (width > 10 && height > 10 && sizeKey !== appliedNativeSize) {
      if (width !== current.width || height !== current.height) window.setBounds({ ...current, width, height });
      appliedNativeSize = sizeKey;
    }
  }
  if (!host.nativeFollowing) appliedNativeSize = '';
  // Stale coordinates never go through setBounds while native following runs.
  if (!host.nativeFollowing && host.visible && host.bounds && [host.bounds.x, host.bounds.y, host.bounds.width, host.bounds.height].every(Number.isFinite)) {
    const rect = screen.screenToDipRect(null, host.bounds);
    const key = JSON.stringify(rect);
    if (rect.width > 10 && rect.height > 10 && appliedBounds !== key) {
      const current = window.getBounds();
      if (rect.width !== current.width || rect.height !== current.height) window.setBounds(rect);
      else window.setPosition(rect.x, rect.y);
      appliedBounds = key; sendCursor(true);
    }
  }
  owner = host.window || '';
  visibility();
}

async function importLegacyStorage() {
  const marker = path.join(dataDir, 'legacy-storage-imported.json');
  if (fs.existsSync(marker) || fixture) return;
  const legacy = new BrowserWindow({ show: false, webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true } });
  session.defaultSession.protocol.handle('http', request => new Response(request.url.startsWith('http://127.0.0.1:47321/') ? '<!doctype html><title>Local migration</title>' : '', { status: request.url.startsWith('http://127.0.0.1:47321/') ? 200 : 403, headers: { 'Content-Type': 'text/html' } }));
  try {
    await legacy.loadURL('http://127.0.0.1:47321/');
    const old = await legacy.webContents.executeJavaScript("Object.fromEntries(Object.keys(localStorage).filter(k => /^dshw[-v]/.test(k)).map(k => [k, localStorage.getItem(k)]))");
    storeValues({ ...old, ...values() }); save(marker, { complete: true, at: new Date().toISOString() });
  } finally { legacy.destroy(); session.defaultSession.protocol.unhandle('http'); }
}

if (!lock) app.quit();
else {
  app.on('second-instance', show);
  app.whenReady().then(async () => {
    markStartup('appReady');
    const { createDispatcher, UI_ORIGIN } = await import(pathToFileURL(path.join(root, 'runtime', 'dispatcher.mjs')));
    const { startBridge } = await import(pathToFileURL(path.join(root, 'runtime', 'bridge.mjs')));
    let testOptions = {};
    if (fixture) { const { makeFixture } = await import(pathToFileURL(path.join(root, 'tests', 'desktop-fixture.mjs'))); testOptions = await makeFixture(dataDir); }
    dispatcher = createDispatcher({ dataDir, fetchImpl: (url, options) => net.fetch(url, options), onStop: pauseAndQuit, onShow: show, statusInfo: () => ({ followCodex: true, hostPid: lastHost?.hostPid || null, visible: !!window?.isVisible(), nativeFollowing: !!lastHost?.nativeFollowing, startup, rendering: gpuStatus }), ...testOptions });
    markStartup('dispatcherReady');
    await importLegacyStorage();
    session.defaultSession.protocol.handle('whale', async request => {
      const url = new URL(request.url);
      if (url.host !== 'widget') return new Response('', { status: 403 });
      const result = await dispatcher.dispatch(url.pathname + url.search, { method: request.method, body: ['GET', 'HEAD'].includes(request.method) ? null : Buffer.from(await request.arrayBuffer()), headers: Object.fromEntries(request.headers) });
      return new Response(request.method === 'HEAD' ? null : result.body, { status: result.status, headers: result.headers });
    });
    const firstBounds = initialHost?.bounds;
    const area = firstBounds && ['x','y','width','height'].every(k => Number.isFinite(firstBounds[k])) && firstBounds.width > 10 && firstBounds.height > 10
      ? screen.screenToDipRect(null, firstBounds) : screen.getPrimaryDisplay().workArea;
    // WS_EX_TOOLWINDOW keeps the large transparent overlay out of Chromium's
    // native occlusion calculation even while its opaque pixels accept clicks.
    // Keep normal activation: Chromium's non-client handler consumes the first
    // mouse down (MA_NOACTIVATEANDEAT) when CanActivate/focusable is false.
    window = new BrowserWindow({ ...area, type: 'toolbar', transparent: true, frame: false, thickFrame: false, resizable: false, maximizable: false, fullscreenable: false, backgroundColor: '#00000000', hasShadow: false, skipTaskbar: true, show: false, title: 'API 余额小鲸鱼', webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required', additionalArguments: fixture ? ['--whale-render-test'] : [] } });
    markStartup('windowCreated');
    window.once('ready-to-show', () => markStartup('frameReady'));
    if (fixture) window.webContents.on('console-message', (_event, ...args) => { const d = args[0]; if (typeof d === 'object' ? d.level === 'error' : d === 3) rendererErrors.push(typeof d === 'object' ? d.message : args[1]); });
    if (!fixture) process.stdout.write(JSON.stringify({ overlayHandle: window.getNativeWindowHandle().readBigUInt64LE().toString() }) + '\n');
    window.setIgnoreMouseEvents(true, { forward: true });
    window.on('show', () => { invalidate(); sendCursor(true); });
    window.on('resize', invalidate);
    window.webContents.on('did-start-loading', () => {
      rendererReady = false; inputEnabled = false;
      visibility();
      setKeyboardFocus(false);
      window.setIgnoreMouseEvents(true, { forward: true });
    });
    window.webContents.setWindowOpenHandler(({ url }) => { openWebLink(url).catch(() => {}); return { action: 'deny' }; });
    window.webContents.on('will-navigate', (event, url) => { if (!url.startsWith(UI_ORIGIN + '/')) event.preventDefault(); });
    session.defaultSession.setPermissionRequestHandler((_web, _permission, callback) => callback(false));
    ipcMain.on('whale-storage', event => { event.returnValue = event.sender === window.webContents ? values() : {}; });
    ipcMain.on('whale-save-storage', (event, input) => { if (event.sender === window.webContents) storeValues(input); });
    ipcMain.on('whale-user-gesture', event => { if (isMainFrame(event)) trustedGestureAt = Date.now(); });
    ipcMain.handle('whale-open-external', (event, url) => isMainFrame(event) ? openWebLink(url) : false);
    ipcMain.on('whale-ready', event => {
      if (event.sender !== window.webContents) return;
      markStartup('imageAndInputReady');
      rendererReady = true; visibility(); invalidate(); sendCursor(true);
    });
    ipcMain.on('whale-interactive', (event, enabled) => {
      if (event.sender !== window.webContents || typeof enabled !== 'boolean' || enabled === inputEnabled) return;
      inputEnabled = enabled;
      window.setIgnoreMouseEvents(!enabled, { forward: true });
    });
    ipcMain.on('whale-keyboard-focus', (event, editing) => {
      if (event.sender === window.webContents && typeof editing === 'boolean') setKeyboardFocus(editing);
    });
    const cursorPoll = setInterval(sendCursor, 50);
    app.once('will-quit', () => clearInterval(cursorPoll));
    const icon = nativeImage.createFromPath(path.join(root, 'assets', 'DSniang1.png')).resize({ width: 24, height: 24 });
    tray = new Tray(icon); tray.setToolTip('API 余额小鲸鱼 · 跟随 Codex');
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: '显示 / 隐藏小鲸鱼', click: toggle },
      { label: '恢复显示小鲸鱼', click: show },
      { label: 'API 设置', click: () => { show(); window.webContents.send('whale-settings'); } },
      { type: 'separator' }, { label: '本次退出挂件（下次打开 Codex 恢复）', click: pauseAndQuit },
    ]));
    tray.on('double-click', toggle); globalShortcut.register('Control+Alt+W', toggle);
    bridge = await startBridge(dispatcher, { dataDir, onHost: setHost });
    markStartup('bridgeReady');
    await window.loadURL(UI_ORIGIN + '/widget.html');
    markStartup('pageLoaded');
    if (lastHost) await setHost(lastHost);
    if (fixture) {
      const fixtureModule = process.env.WHALE_VISIBILITY_STRESS === '1' ? 'visibility-stress-fixture.mjs' : process.env.WHALE_DESKTOP_AUDIT === '1' ? 'desktop-audit-fixture.mjs' : 'desktop-fixture.mjs';
      const { verifyDesktop } = await import(pathToFileURL(path.join(root, 'tests', fixtureModule)));
      await verifyDesktop({ app, window, screen, setHost, setTestCursor, dispatcher, dataDir, errors: rendererErrors, openedLinks: fixtureOpenedLinks, renderInfo: () => ({ gpuStatus, presents, inputEnabled, keyboardFocus, visibility: visibilityController.snapshot() }) });
    }
    else { const heartbeat = setInterval(() => { if (Date.now() - hostHeartbeat > 6000) app.quit(); }, 2000); app.once('will-quit', () => clearInterval(heartbeat)); }
  }).catch(error => { try { save(path.join(dataDir, 'desktop-error.json'), { message: String(error.message).slice(0, 350), at: new Date().toISOString() }); } catch {} app.exit(1); });
  app.on('window-all-closed', () => { if (!quitting && rendererReady) app.quit(); });
  app.on('before-quit', event => {
    event.preventDefault();
    if (quitting) return;
    quitting = true;
    visibilityController.dispose();
    // Do not leave an unresponsive input surface over Codex while saving state.
    try { if (window && !window.isDestroyed()) { window.setIgnoreMouseEvents(true); window.hide(); } } catch {}
    let finished = false;
    const finish = () => {
      if (finished) return; finished = true;
      globalShortcut.unregisterAll(); tray?.destroy();
      // Cleanup above replaces renderer beforeunload: an unresponsive renderer
      // must not be asked to approve quitting a second time.
      app.exit(0);
    };
    const watchdog = setTimeout(finish, 6500);
    shutdownCompanion({
      readRenderer: () => window && !window.isDestroyed() && !window.webContents.isDestroyed() && !window.webContents.isCrashed?.()
        ? window.webContents.executeJavaScript("Object.fromEntries(Object.keys(localStorage).filter(k => /^dshw[-v]/.test(k)).map(k => [k, localStorage.getItem(k)]))") : null,
      saveRenderer: storeValues,
      flushState: () => uiStore.flush(),
      closeBridge: () => bridge?.close(),
      closeDispatcher: () => dispatcher?.close(),
    }).then(result => {
      try { save(path.join(dataDir, 'desktop-shutdown.json'), { at: new Date().toISOString(), ...result }); } catch {}
    }).catch(() => {}).finally(() => { clearTimeout(watchdog); finish(); });
  });
}
